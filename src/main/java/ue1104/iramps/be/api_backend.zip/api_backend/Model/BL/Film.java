package ue1104.iramps.be.api_backend.Model.BL;


import jakarta.persistence.*;

@Entity
@Table(name = "film")

public class Film {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id_film")
    private Long idFilm;

    @Column(name = "titre", length = 100, nullable = false)
    private String titre;

    @Column(name = "duree")
    private int duree;

    @Column(name = "description")
    private String description;

    
    
    // --- Constructeurs ---
    public Film() {
    }

    public Film(String titre, int duree, String description) {
        this.titre = titre;
        this.duree = duree;
        this.description = description;
    }

    // --- Getters et Setters ---
    public Long getIdFilm() {
        return idFilm;
    }

    public void setIdFilm(Long idFilm) {
        this.idFilm = idFilm;
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public int getDuree() {
        return duree;
    }

    public void setDuree(int duree) {
        this.duree = duree;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}

