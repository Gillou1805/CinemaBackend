package ue1104.iramps.be.api_backend.Model.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import ue1104.iramps.be.api_backend.Model.BL.Creneau;
import ue1104.iramps.be.api_backend.Model.IntermediateTable.CalendrierKey;

import java.util.List;

public interface CreneauRepository extends JpaRepository<Creneau, Long> {

    /** Recherche tous les créneaux dont la clé composite de calendrier est passée. */
    List<Creneau> findByCalendrier_Id(CalendrierKey calendrierKey);

}
