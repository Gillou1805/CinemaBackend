package ue1104.iramps.be.api_backend.Service;

import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;
import ue1104.iramps.be.api_backend.Model.BL.Film;
import ue1104.iramps.be.api_backend.Model.Repositories.FilmRepository;
import java.util.List;

@Service
public class FilmService {
    private final FilmRepository repo;

    public FilmService(FilmRepository repo) {
        this.repo = repo;
    }

    public List<Film> findAll() {
        return repo.findAll();
    }

    public Film findById(Long id) {
        return repo.findById(id)
                   .orElseThrow(() -> new ResponseStatusException(
                       HttpStatus.NOT_FOUND, "Film introuvable"
                   ));
    }
}
