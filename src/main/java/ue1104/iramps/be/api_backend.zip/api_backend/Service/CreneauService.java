// src/main/java/ue1104/iramps/be/api_backend/Service/CreneauService.java
package ue1104.iramps.be.api_backend.Service;

import org.springframework.stereotype.Service;
import ue1104.iramps.be.api_backend.Model.BL.Creneau;
import ue1104.iramps.be.api_backend.Model.IntermediateTable.CalendrierKey;
import ue1104.iramps.be.api_backend.Model.Repositories.CreneauRepository;
import java.util.List;

@Service
public class CreneauService {

    private final CreneauRepository repo;

    public CreneauService(CreneauRepository repo) {
        this.repo = repo;
    }

    public List<Creneau> getByCalendrier(CalendrierKey key) {
        return repo.findByCalendrier_Id(key);
    }

    public Creneau save(Creneau creneau) {
        return repo.save(creneau);
    }

    public void delete(Long id) {
        repo.deleteById(id);
    }
}
