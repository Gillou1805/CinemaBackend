// src/main/java/ue1104/iramps/be/api_backend/Controller/FilmController.java
package ue1104.iramps.be.api_backend.Controller;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import ue1104.iramps.be.api_backend.Model.BL.Film;
import ue1104.iramps.be.api_backend.Model.Repositories.FilmRepository;

import java.util.List;

@RestController
@RequestMapping("/api/films")      // <-- passé de "/api/film" à "/api/films"
public class FilmController {

    private final FilmRepository repo;

    public FilmController(FilmRepository repo) {
        this.repo = repo;
    }

    @GetMapping
    public List<Film> all() {
        return repo.findAll();
    }

    @GetMapping("/{id}")
    public Film one(@PathVariable Long id) {
        return repo.findById(id)
                   .orElseThrow(() -> new ResponseStatusException(
                       HttpStatus.NOT_FOUND, "Film introuvable"
                   ));
    }
}
