package ue1104.iramps.be.api_backend.Security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import ue1104.iramps.be.api_backend.Model.Repositories.UtilisateurRepository;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private final JwtUtil jwtUtil;

    public SecurityConfig(JwtUtil jwtUtil) {
        this.jwtUtil = jwtUtil;
    }

    // 1) On recrée le bean UserDetailsService à partir de votre repo
    @Bean
    public UserDetailsService userDetailsService(UtilisateurRepository repo) {
        return username -> repo.findByMail(username)
            .map(u -> org.springframework.security.core.userdetails.User.withUsername(u.getMail())
                                  .password(u.getMdp())
                                  .roles(u.getRole())
                                  .build()
            )
            .orElseThrow(() ->
                new org.springframework.security.core.userdetails.UsernameNotFoundException("Utilisateur introuvable")
            );
    }

    // 2) PasswordEncoder pour BCrypt
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    // 3) Provider DAO (userDetails + encoder)
    @Bean
    public DaoAuthenticationProvider authenticationProvider(UserDetailsService uds,
                                                            PasswordEncoder encoder) {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService(uds);
        provider.setPasswordEncoder(encoder);
        return provider;
    }

    // 4) AuthenticationManager
    @Bean
    public AuthenticationManager authenticationManager(DaoAuthenticationProvider authProvider) {
        return new ProviderManager(authProvider);
    }

    // 5) Sécurité HTTP + JWT filters
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http,
                                                   AuthenticationManager authManager,
                                                   UserDetailsService uds) throws Exception {
        http
          .cors().and()                        // CORS configuré plus bas
          .csrf().disable()                    // Désactivation CSRF (API REST stateless)
          .sessionManagement(sm -> sm
              .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
          )
          .authorizeHttpRequests(auth -> auth
              // 1) Autoriser tous les preflight CORS
              .requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()

              // 2) Autoriser Swagger et OpenAPI en « lecture »
              .requestMatchers("/v3/api-docs/**").permitAll()
              .requestMatchers("/swagger-ui/**").permitAll()
              .requestMatchers("/swagger-ui.html").permitAll()

              // 3) Autoriser votre endpoint d’erreur
              .requestMatchers("/error").permitAll()

              // 4) Vos routes publiques GET
              .requestMatchers(HttpMethod.GET, "/api/salles/**").permitAll()
              .requestMatchers(HttpMethod.GET, "/api/films/**").permitAll()
              .requestMatchers(HttpMethod.GET, "/api/semainaire/**").permitAll()
              .requestMatchers("/api/auth/**").permitAll()

              // 5) Pour tout ce qui est POST/PUT/DELETE sur /api/salles/**, rôle ADMIN
              .requestMatchers(HttpMethod.POST,   "/api/salles/**").hasRole("ADMIN")
              .requestMatchers(HttpMethod.PUT,    "/api/salles/**").hasRole("ADMIN")
              .requestMatchers(HttpMethod.DELETE, "/api/salles/**").hasRole("ADMIN")

              // 6) Toutes les autres requêtes doivent être authentifiées
              .anyRequest().authenticated()
          )
          // On branche notre provider (UserDetailsService + PasswordEncoder)
          .authenticationProvider(authenticationProvider(uds, passwordEncoder()))
          // On ajoute les filtres JWT
          .addFilter(new JwtAuthenticationFilter(authManager, jwtUtil))
          .addFilterAfter(new JwtAuthorizationFilter(jwtUtil, uds),
                          JwtAuthenticationFilter.class);

        return http.build();
    }


    // 6) CORS pour Angular
    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer(){
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/**")
                        .allowedOrigins("http://localhost:4200")
                        .allowedMethods("GET","POST","PUT","DELETE","OPTIONS")
                        .allowedHeaders("*")
                        .allowCredentials(true);
            }
        };
    }
    
    
}

