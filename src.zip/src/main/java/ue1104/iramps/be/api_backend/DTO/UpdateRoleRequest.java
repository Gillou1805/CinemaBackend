// src/main/java/ue1104/iramps/be/api_backend/DTO/UpdateRoleRequest.java
package ue1104.iramps.be.api_backend.DTO;
import ue1104.iramps.be.api_backend.DTO.UpdateRoleRequest;


public class UpdateRoleRequest {
    private String role;
    public UpdateRoleRequest() { }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
}
